import SwiftUI

struct ContentView: View {
    @State private var targetColor: Color = .blue
    @State private var currentColor: Color = .white
    
    var body: some View {
        ZStack {
            currentColor
                .edgesIgnoringSafeArea(.all)
                .onTapGesture {
                    updateBackgroundColor()
                }
        }
    }
    
    func updateBackgroundColor() {
        currentColor = generateRandomColor()
    }
    
    func generateRandomColor() -> Color {
        let red = Double.random(in: 0...1)
        let green = Double.random(in: 0...1)
        let blue = Double.random(in: 0...1)
        
        return Color(red: red, green: green, blue: blue)
    }
}

@main
struct ColorMatchingGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

