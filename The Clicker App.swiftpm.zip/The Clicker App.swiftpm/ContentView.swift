import SwiftUI

struct ClickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .background(Color(red: 0.95, green: 0.95, blue: 0.98)) 
        }
    }
}

struct ContentView: View {
    @State private var count = 0
    
    var body: some View {
        VStack {
            Text("Clicker App")
                .font(.title)
                .foregroundColor(.blue) 
            
            Spacer()
            
            Text("\(count)")
                .font(.largeTitle)
                .padding()
                .foregroundColor(.green) 
            
            HStack {
                Button(action: {
                    count += 1
                }) {
                    Image(systemName: "plus.circle")
                        .font(.largeTitle)
                }
                .padding()
                .foregroundColor(.red) 
                
                Button(action: {
                    if count > 0 {
                        count -= 1
                    }
                }) {
                    Image(systemName: "minus.circle")
                        .font(.largeTitle)
                }
                .padding()
                .foregroundColor(.red) 
            }
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .background(Color(red: 0.95, green: 0.95, blue: 0.98)) 
    }
}

