import SwiftUI

struct TodoItem: Identifiable {
    let id = UUID()
    var title: String
    var description: String
    var isCompleted = false
}

struct ContentView: View {
    
    @State private var todoItems: [TodoItem] = [
        TodoItem(title: "Buy groceries", description: "Milk, eggs, bread"),
        TodoItem(title: "Finish homework", description: "Math assignment"),
        TodoItem(title: "Ask Dad to buy the Milk", description: "DISCLAIMER: He'll never come back"),
        TodoItem(title: "SECRET TASK", description: "https://www.youtube.com/watch?v=dQw4w9WgXcQ")
    ]
    
    @State private var showAddItemView = false
    
    var body: some View {
        NavigationView {
            VStack(alignment: .leading) {
                Text("What You Need to Do")
                    .font(.largeTitle)
                    .padding()
                    .foregroundColor(.green)
                
                Spacer()
                
                List {
                    ForEach(todoItems) { item in
                        NavigationLink(destination: DetailView(item: item)) {
                            Text(item.title)
                                .foregroundColor(.indigo)
                        }
                        .contextMenu {
                            Button(action: {
                                toggleCompletion(for: item)
                            }) {
                                HStack {
                                    Text(item.isCompleted ? "Mark as Not Done" : "Mark as Done")
                                    Image(systemName: item.isCompleted ? "circle" : "checkmark.circle")
                                }
                            }
                            
                            Button(action: {
                                deleteItem(item)
                            }) {
                                HStack {
                                    Text("Delete")
                                    Image(systemName: "trash")
                                }
                            }
                        }
                    }
                    .onMove(perform: moveItem)
                }
                
                Spacer()
                
                HStack {
                    Spacer()
                    Button(action: {
                        showAddItemView.toggle()
                    }) {
                        Image(systemName: "plus.circle.fill")
                        Text("Add Item")
                    }
                    .padding()
                    .sheet(isPresented: $showAddItemView) {
                        AddItemView(todoItems: $todoItems)
                    }
                }
            }
            .navigationBarTitle("To-Do List")
            .navigationBarItems(trailing: EditButton())
        }
    }
    
    func toggleCompletion(for item: TodoItem) {
        if let index = todoItems.firstIndex(where: { $0.id == item.id }) {
            todoItems[index].isCompleted.toggle()
        }
    }
    
    func deleteItem(_ item: TodoItem) {
        if let index = todoItems.firstIndex(where: { $0.id == item.id }) {
            todoItems.remove(at: index)
        }
    }
    
    func moveItem(from source: IndexSet, to destination: Int) {
        todoItems.move(fromOffsets: source, toOffset: destination)
    }
}

struct DetailView: View {
    let item: TodoItem
    
    var body: some View {
        VStack {
            Text(item.title)
                .font(.title)
                .padding()
            
            Text(item.description)
                .font(.subheadline)
                .foregroundColor(.gray)
                .padding()
            
            Text(item.isCompleted ? "Completed" : "Not completed")
                .foregroundColor(item.isCompleted ? .green : .red)
                .padding()
        }
    }
}

struct AddItemView: View {
    @Binding var todoItems: [TodoItem]
    @State private var newItemTitle = ""
    
    var body: some View {
        NavigationView {
            VStack {
                TextField("New Item Title", text: $newItemTitle)
                    .padding()
                
                Text("Delete task once done")
                
                Button(action: {
                    if !newItemTitle.isEmpty {
                        todoItems.append(TodoItem(title: newItemTitle, description: ""))
                        newItemTitle = ""
                    }
                }) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                        Text("Add")
                    }
                }
                .padding()
            }
            .navigationBarTitle("Add Item")
        }
    }
}

