import SwiftUI

struct Book: Identifiable {
    var id = UUID()
    var title: String
    var author: String
}

struct ContentView: View {
    @State var books: [Book] = [
        .init(title: "Harry Potter and the Sorcerer's Stone", author: "J.K. Rowling"),
        .init(title: "Charlie and The Cholcalate Factory", author: "Roald Dahl"),
        .init(title: "Percy Jackson and The Lightning Theif", author: "Rick Riordan")
    ]
    
    var body: some View {
        VStack {
            ForEach(books) { book in
                Text("Title: \(book.title)\nAuthor: \(book.author)")
                    .padding()
                    .border(Color.gray, width: 1)
                    .cornerRadius(5)
            }
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

